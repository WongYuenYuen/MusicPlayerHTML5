<?php

if(true){
    echo 'okay';
}else if(false){
    echo 'failed';
}
?>
